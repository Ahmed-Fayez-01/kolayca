package com.alameer.kolayca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
