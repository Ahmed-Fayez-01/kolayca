import 'package:flutter/material.dart';

class AppColor {
  static Color deebGrey = const Color(0xffbac7e8384);
  static const Color deebPlue = Color(0xff2F2262);
  static Color plueLight = const Color(0xff69C1FE);
  static Color ofWhight = const Color(0xffEBEBEB);
}
