import 'package:flutter/material.dart';

class LiveTranslatorZgoCallView extends StatefulWidget {
  const LiveTranslatorZgoCallView({super.key});

  @override
  State<LiveTranslatorZgoCallView> createState() =>
      _LiveTranslatorZgoCallViewState();
}

class _LiveTranslatorZgoCallViewState extends State<LiveTranslatorZgoCallView> {
  @override
  Widget build(BuildContext context) {
    return const Card();
  }
}
